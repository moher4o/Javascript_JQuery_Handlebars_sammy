import Entity from './entity.js'
import Dog from './dog.js'
import Person from './person.js'
import Student from './student.js'

result.Entity = Entity
result.Dog = Dog
result.Person = Person
result.Student = Student