function mapSort(map, sortFn){
    if(sortFn){
        let mapKeys = Array.from(map.keys())
            .sort(sortFn)
        let myMap = new Map()
        for (let key of mapKeys) {
            myMap.set(key, map.get(key))
        }
        return myMap
    }
    else{
        let mapKeys = Array.from(map.keys())
            .sort((w,v) => {
                if(typeof w === 'number')
                    return w-v
                else
                    return w.localeCompare(v)
            })
        let myMap = new Map()
        for (let key of mapKeys) {
            myMap.set(key, map.get(key))
        }
        return myMap

    }
}

module.exports = mapSort
