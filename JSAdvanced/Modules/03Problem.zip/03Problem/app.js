let actions = require('./actions')

result.sort = actions.sort
result.filter = actions.filter

//console.log(actions.sort('shipTo'));
//console.log(actions.filter('status', 'shipped'));